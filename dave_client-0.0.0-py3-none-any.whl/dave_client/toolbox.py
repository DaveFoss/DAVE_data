# Copyright (c) 2022-2023 by Fraunhofer Institute for Energy Economics and Energy System Technology (IEE)
# Kassel and individual contributors (see AUTHORS file for details). All rights reserved.
# Use of this source code is governed by a BSD-style license that can be found in the LICENSE file.

import geopandas as gpd
from shapely.geometry import MultiLineString
from shapely.ops import linemerge


def multiline_coords(line_geometry):
    """
    This function extracts the coordinates from a MultiLineString

    INPUT:
    **line_geometry** (Shapely MultiLinesString) - geometry in MultiLineString format

    OUTPUT:
        **line_coords** (list) - coordinates of the given MultiLineString
    """
    merged_line = linemerge(line_geometry)
    # sometimes line merge can not merge the lines correctly
    line_coords = []
    if isinstance(merged_line, MultiLineString):
        for line in list(merged_line.geoms):
            line_coords += line.coords[:]
    else:
        line_coords += merged_line.coords[:]
    return line_coords


def lines_to_polygon(lines, buffer=100, crs="epsg:4326", convex_hull=True):
    """
    Calculation of a polygon on the basis of LineStrings and the inclusion of a buffer.
    The crs will temporary project to epsg 3035 for adding the buffer in meter as unit

    Input:
         **lines** (GeoDataFrame) - Table with LineString geometries
         **buffer** (float, 0.01) - Buffer around the considered network elements
         **crs** (str, 'epsg:4326') - Definition of the network coordinate reference system
         **convex_hull** (boolean, True)- If true the the convex hull will calculated for the given \
             lines instaed of onyly using a buffer around the lines 

    OUTPUT:
         **polygon** (Shapely polygon) - Polygon which defines the area for LineStrings

    """
    # change crs for using meter as unit
    if crs != "epsg:3035":
        lines.to_crs(crs="epsg:3035", inplace=True)
    # define considered area
    if convex_hull:
        area = lines.geometry.unary_union.convex_hull
        # add buffer to the grid_area polygon
        area_buffer = area.buffer(buffer)
        area_buffer = gpd.GeoSeries([area_buffer], crs="epsg:3035")
        area_buffer = area_buffer.to_crs(crs=crs)
    else:
        # Create MultiLineString from Lines and merge them
        lines_merged = linemerge(lines.geometry.to_list())
        area = gpd.GeoSeries(lines_merged, crs="epsg:3035")
        # add buffer to the grid_area polygon
        area_buffer = area.buffer(buffer)
        area_buffer = area_buffer.to_crs(crs=crs)
    return area_buffer.iloc[0]
