# Copyright (c) 2022-2023 by Fraunhofer Institute for Energy Economics and Energy System Technology (IEE)
# Kassel and individual contributors (see AUTHORS file for details). All rights reserved.
# Use of this source code is governed by a BSD-style license that can be found in the LICENSE file.

from shapely.geometry import MultiLineString
from shapely.ops import linemerge


def multiline_coords(line_geometry):
    """
    This function extracts the coordinates from a MultiLineString

    INPUT:
    **line_geometry** (Shapely MultiLinesString) - geometry in MultiLineString format

    OUTPUT:
        **line_coords** (list) - coordinates of the given MultiLineString
    """
    merged_line = linemerge(line_geometry)
    # sometimes line merge can not merge the lines correctly
    line_coords = []
    if isinstance(merged_line, MultiLineString):
        for line in list(merged_line.geoms):
            line_coords += line.coords[:]
    else:
        line_coords += merged_line.coords[:]
    return line_coords
