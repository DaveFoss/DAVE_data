import json
import os

import geopandas as gpd
import pandas as pd
import requests
from pandapower.file_io import from_json_string as from_json_string_pp
from pandapower.io_utils import PPJSONEncoder
from shapely.geometry import Polygon

from dave_client.io.file_io import from_json_string, isinstance_partial
from dave_client.settings import check_server_availibility, client_settings


def login(user_name, user_password):
    """
    This function is login to the DAVE api and requests a jwt

    INPUT:
        **user_name** (str) - user name for the DAVE account
        **user_password** (str) - user passwprd for the DAVE account

    OUTPUT:
        **auth_token** (dict) - authentication token for the DAVE account

    """
    # check dave availability
    check_server_availibility()
    # request token
    request_token = requests.get(
        client_settings()["dave_server_url"] + "/login",
        data=json.dumps(
            {
                "user_name": user_name,
                "user_password": user_password,
            }
        ),
    )
    token = request_token.json()
    if token == "invalid user credentials":
        raise ValueError("invalid user credentials")
    else:
        print("successful loged in to DAVE api")
        # store token
        json.dump(
            token, open(f"{os.path.dirname(os.path.abspath(__file__))}" + "\\token.json", "w")
        )


def read_token():
    """
    This function reads the token from stored file within login
    """
    return json.load(open(f"{os.path.dirname(os.path.abspath(__file__))}" + "\\token.json", "r"))


def create_dataset(
    postalcode=None,
    town_name=None,
    federal_state=None,
    nuts_region=None,
    own_area=None,
    geodata=[],
    power_levels=[],
    gas_levels=[],
    convert_power=[],
    convert_gas=[],
    opt_model=True,
    combine_areas=[],
    transformers=True,
    renewable_powerplants=True,
    conventional_powerplants=True,
    loads=True,
    compressors=True,
    sinks=True,
    sources=True,
    storages_gas=True,
    valves=True,
    census=[],
):
    """
    This function requests a DAVE dataset via api
    
    INPUT:
        One of these parameters must be set: \n
        **postalcode** (List of strings) - numbers of the target postalcode areas. it could also \
            be choose ['ALL'] for all postalcode areas in germany \n
        **town_name** (List of strings) - names of the target towns it could also be choose \
            ['ALL'] for all citys in germany \n
        **federal_state** (List of strings) - names of the target federal states it could also be \
            choose ['ALL'] for all federal states in germany \n
        **nuts_region** (tuple(List of strings, string)) - this tuple includes first a list of the \
            target nuts regions codes (independent from nuts level). It could also be choose \
            ['ALL'] for all nuts regions in europe. The second tuple parameter defines the nuts \
            year as string.\n
        **own_area** (string / Polygon) - First Option for this parameter is to hand over a string \
            which represents the absolute path to a shape file which includes own target area \
            (e.g. "C:/Users/name/test/test.shp"). The second option is to hand over a shapely \
            Polygon which defines the area. \n

    OPTIONAL:
        **geodata** (list, default []) - this parameter defines which geodata should be considered.\
            options: 'roads','roads_plot','buildings','landuse', 'railways', 'waterways', []. \
                there could be choose: one/multiple geoobjects or 'ALL' \n
        **power_levels** (list, default []) - this parameter defines which power levels should be \
            considered. options: 'ehv','hv','mv','lv', []. there could be choose: one/multiple \
                level(s) or 'ALL' \n
        **gas_levels** (list, default []) - this parameter defines which gas levels should be \
            considered. options: 'hp','mp','lp', []. there could be choose: one/multiple level(s) \
            or 'ALL' \n
        **convert_power** (list, default []) - this parameter defines in witch formats the power \
            grid data should be converted. Available formats are currently: 'pandapower' \n
        **convert_gas** (list, default []) - this parameter defines in witch formats the gas \
            grid data should be converted. Available formats are currently: 'pandapipes', \
                'gaslib' \n
        **opt_model** (boolean, default True) - if this value is true dave will be use the optimal \
            power flow calculation to get no boundary violations. Currently a experimental feature \
                and only available for pandapower \n
        **combine_areas** (list, default []) - this parameter defines on which power levels not \
            connected areas should combined. options: 'EHV','HV','MV','LV', [] \n
        **transformers** (boolean, default True) - if true, transformers are added to the grid \
            model \n
        **renewable_powerplants** (boolean, default True) - if true, renewable powerplans are \
            added to the grid model \n
        **conventional_powerplants** (boolean, default True) - if true, conventional powerplans \
            are added to the grid model \n
        **loads** (boolean, default True) - if true, loads are added to the grid model \n
        **compressors** (boolean, default True) - if true, compressors are added to the grid \
            model \n
        **sinks** (boolean, default True) - if true, gas sinks are added to the grid model \n
        **sources** (boolean, default True) - if true, gas sources are added to the grid model \n
        **storages_gas** (boolean, default True) - if true, gas storages are added to the grid \
            model \n
        **valves** (boolean, default True) - if true, gas valves are added to the grid model \n
        **census**  (list, default []) - this parameter defines which census data should be \
            considered. Options: 'population', []. there could be choose: one/multiple geoobjects \
            or 'ALL' \n

    OUTPUT:
        **grid_data** (dict) - DAVE dataset

    """
    # if user selected the option to hand over an own area, this has to be adjusted to work with the DAVE api
    if own_area:
        if isinstance(own_area, str):
            if own_area[-3:] == "shp":
                target = gpd.read_file(own_area)
            else:
                target = from_json_string(own_area)
            # check if the given shape file is empty
            if target.empty:
                print("The given shapefile includes no data")
        elif isinstance(own_area, Polygon):
            target = gpd.GeoDataFrame(
                {"name": ["own area"], "geometry": [own_area]}, crs=client_settings()["crs_main"]
            )
        else:
            print("The given format is unknown")
        own_area = json.dumps(
            target, cls=PPJSONEncoder, indent=2, isinstance_func=isinstance_partial
        )
    request_dataset = requests.get(
        client_settings()["dave_server_url"] + "/request_dataset",
        data=json.dumps(
            {
                "auth_token": read_token(),
                "postalcode": postalcode,
                "town_name": town_name,
                "federal_state": federal_state,
                "nuts_regions": nuts_region,
                "own_area": own_area,
                "geodata": geodata,
                "power_levels": power_levels,
                "gas_levels": gas_levels,
                "convert_power": convert_power,
                "convert_gas": convert_gas,
                "opt_model": opt_model,
                "combine_areas": combine_areas,
                "transformers": transformers,
                "renewable_powerplants": renewable_powerplants,
                "conventional_powerplants": conventional_powerplants,
                "loads": loads,
                "compressors": compressors,
                "sinks": sinks,
                "sources": sources,
                "storages_gas": storages_gas,
                "valves": valves,
                "census": census,
            }
        ),
    )
    # !!! hier noch check hin machen ob token is valid
    # read data from request

    # return request_dataset
    if convert_power == [] and convert_gas == []:
        # only DAVE dataset
        return from_json_string(request_dataset.json())
    if "pandapower" in convert_power and convert_gas == []:
        request_data = eval(request_dataset.json())
        dave_dataset = from_json_string(request_data["grid_data"])
        net_pp = from_json_string_pp(request_data["net_power"])
        return dave_dataset, net_pp


def db_info():
    """
    This function returns the main informations about the dave databnase. This includes all
    databases and their collections.

    OUTPUT:
        **grid_data** (dict) - DAVE dataset

    """
    request_info = requests.get(
        client_settings()["dave_server_url"] + "/db_info",
        data=json.dumps(
            {
                "auth_token": read_token(),
            }
        ),
    )
    return request_info.json()


def from_database(database, collection, filter_method=None, filter_param=None, filter_value=None):
    """
    This function requests data from the dave database.
    
    INPUT:
        **database** (string) - name of the database \n
        **collection** (string) - nome of the collection \n

    OPTIONAL:
        **filter_method** (string, default None) - method for the data filtering. Examples: \n
        "eq" - matches documents where the value of a field equals the specified value. \n
        "geoIntersects" - Selects documents whose geospatial data intersects with a specified \
                geometrical object \n
        **filter_param** (string, default None) - parameter to be filtered by \n
        **filter_value** (string, default None) - value for the filtering
    
    OUTPUT:
        **db_data** (GeoDataFrame) - data from the requested collection

    """
    request_collection = requests.get(
        client_settings()["dave_server_url"] + "/request_db",
        data=json.dumps(
            {
                "auth_token": read_token(),
                "database": database,
                "collection": collection,
                "filter_method": filter_method,
                "filter_param": filter_param,
                "filter_value": filter_value,
            }
        ),
    )
    data = json.loads(request_collection.json())
    if "type" in data.keys() and data["type"] == "FeatureCollection":
        return gpd.GeoDataFrame.from_features(data)
    else:
        return pd.DataFrame(data)


def to_database(database, collection, data, merge=False):
    """
    This function uploads data to the dave database. For this you need a DAVE account with \
    developer rights

    INPUT:
        **database** (string) - name of the database \n
        **collection** (string) - name of the collection \n
        **data** (GeoDataFrame) - data which should upload to the DAVE database \n
        **merge** (boolean, False) - If True the uploaded data will be merged \
            into an existing collection
    """
    # split large datasets by 10000 rows to avoid memory errors
    max_rows = 10000
    for i in range(int(len(data) / max_rows) + 1):
        request_message = requests.post(
            client_settings()["dave_server_url"] + "/post_db",
            data=json.dumps(
                {
                    "auth_token": read_token(),
                    "database": database,
                    "collection": collection,
                    "data": data[i * max_rows : (i + 1) * max_rows - 1].to_json(),
                    "merge": False
                    if (i == 0 and merge == False)
                    else True,  # create database for the first entries
                }
            ),
        )
    return request_message.json()


def drop_collection(database, collection):
    """
    This function drops a collection from the DAVE database. For this you need a DAVE account with \
    db_admin rights.

    INPUT:
        **database** (string) - name of the database \n
        **collection** (string) - name of the collection which should be droped \n
    """
    request_message = requests.get(
        client_settings()["dave_server_url"] + "/drop_collection_db",
        data=json.dumps(
            {
                "auth_token": read_token(),
                "database": database,
                "collection": collection,
            }
        ),
    )
    return request_message.json()


def create_databases(database_names):
    """
    This function creates new databases in the DAVE db. For this you need a DAVE account with \
    db_admin rights.

    INPUT:
        **database_names** (list) - names of the databases which should be create  \n
    """
    request_message = requests.get(
        client_settings()["dave_server_url"] + "/create_database_db",
        data=json.dumps(
            {
                "auth_token": read_token(),
                "database_names": database_names,
            }
        ),
    )
    return request_message.json()
