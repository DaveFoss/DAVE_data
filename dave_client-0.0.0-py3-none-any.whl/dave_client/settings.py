# switch develop and production parameters
develop = False # set True for develop modus
if develop:
    # DAVE api url in develop mode
    dave_server_url = url = "http://127.0.0.1/api"
else:
    # DAVE api url in production mode
    dave_server_url = "http://databutler.energy/api"


def client_settings():
    """
    This function returns a dictonary with the DAVE client settings
    """
    settings = {
        # system definitions
        "dave_server_url": dave_server_url,
        # geographical defintions:
        "crs_main": "EPSG:4326",  # crs which is based on the unit degree
    }
    return settings
