import requests

# switch develop and production parameters
develop = True  # set True for develop modus
if develop:
    # DAVE api url in develop mode
    dave_server_url = "http://127.0.0.1/api"
else:
    # DAVE api url in production mode
    dave_server_url = "http://databutler.energy/api"


def check_server_availibility():
    """
    This function checks the avalibility of the DAVE server
    """
    try:
        request = requests.get(dave_server_url)
        if request.status_code == 200:
            available = True
        elif request.status_code == 404:
            available = False
    except requests.ConnectionError:
        available = False
        if develop == False:
            raise ConnectionError(
                "The DAVE server is currently not available. \
                                  Please try it again later and/or contact the \
                                  responsible persons"
            )
    return available


def client_settings():
    """
    This function returns a dictonary with the DAVE client settings
    """
    settings = {
        # system definitions
        "dave_server_url": dave_server_url,
        # request current DAVE version from server
        "dave_version": requests.get(dave_server_url + "/version")
        if check_server_availibility()
        else "Not available",
        # geographical defintions:
        "crs_main": "EPSG:4326",  # crs which is based on the unit degree
        # structural definitions:
        "bar_format": "{desc:<10}{percentage:5.0f}%|{bar:30}| completed",  # format progress bar
        # --- assumptions at gas grid generating:
        # hp level
        "hp_nodes_height_m": 1,  # dummy value, must be changed
        "hp_pipes_k_mm": float(0.1),  # value based on shutterwald data, must be changed
        "hp_pipes_tfluid_k": 273.15,  # dummy value , must be changed
        # --- assumptions at pandapower convert:
        # lines standard types
        "mv_line_std_type": "NA2XS2Y 1x240 RM/25 12/20 kV",  # dummy value, must be changed
        "lv_line_std_type": "NAYY 4x150 SE",  # dummy value, must be changed
        # trafo parameters for ehv/ehv and  ehv/hv. The dummy values are based on the pandapower
        # standarttype "160 MVA 380/110 kV" which is the biggest model
        "trafo_vkr_percent": 0.25,  # dummy value
        "trafo_vk_percent": 12.2,  # dummy value
        "trafo_pfe_kw": 60,  # dummy value
        "trafo_i0_percent": 0.06,  # dummy value
        # trafo standard types
        "hvmv_trafo_std_type": "63 MVA 110/20 kV",  # dummy value, must be changed
        "mvlv_trafo_std_type": "0.63 MVA 20/0.4 kV",  # dummy value, must be changed
        # conversion gasdata
        "factor_mw_to_kb_per_s": 0.006961,  # converting factor for gas 1000 MW <-> 6.961 kg/s
    }
    return settings
