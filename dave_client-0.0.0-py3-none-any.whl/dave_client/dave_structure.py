import geopandas as gpd
import pandas as pd
from pandapower.auxiliary import ADict

from dave_client.settings import client_settings


class davestructure(ADict):
    """
    This class is for the davestracture as attributed dictionary and to makes it possible to \
    showing a overview of the DAVE dataset in the python console
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if isinstance(args[0], self.__class__):
            net = args[0]
            self.clear()
            self.update(**net.deepcopy())

    def __repr__(self):  # pragma: no cover
        titel = "This DAVE dataset includes the following parameter tables:"
        for key in list(self.keys()):
            if isinstance(self[key], pd.DataFrame) and not self[key].empty:
                length = len(self[key])
                titel += f'\n   - {key} ({length} {"elements" if length > 1 else "element"})'
            if isinstance(self[key], davestructure):
                titel += f"\n   - {key}:"
                for key2 in list(self[key].keys()):
                    if isinstance(self[key][key2], pd.DataFrame) and not self[key][key2].empty:
                        length = len(self[key][key2])
                        titel += (
                            f'\n\t   - {key2} ({length} {"elements" if length > 1 else "element"})'
                        )
                    if isinstance(self[key][key2], davestructure):
                        titel += f"\n\t   - {key2}:"
                        for key3 in list(self[key][key2].keys()):
                            if (
                                isinstance(self[key][key2][key3], pd.DataFrame)
                                and not self[key][key2][key3].empty
                            ):
                                length = len(self[key][key2][key3])
                                titel += f'\n\t\t   - {key3} ({length} {"elements" if length > 1 else "element"})'
        return titel


def create_empty_dataset():
    """
    This function initializes the dave datastructure and create all possible data categories

    OUTPUT:
        **grid_data** (attrdict) - dave attrdict with empty tables

    EXAMPLE:
        grid_data = create_empty_dataset()

    """
    # define dave structure
    grid_data = davestructure(
        {
            # target data
            "area": gpd.GeoDataFrame([]),
            "target_input": pd.DataFrame(),
            "buildings": davestructure(
                {
                    "commercial": gpd.GeoDataFrame([]),
                    "residential": gpd.GeoDataFrame([]),
                    "other": gpd.GeoDataFrame([]),
                }
            ),
            "roads": davestructure(
                {
                    "roads": gpd.GeoDataFrame([]),
                    "roads_plot": gpd.GeoDataFrame([]),
                    "road_junctions": gpd.GeoSeries([]),
                }
            ),
            "landuse": gpd.GeoDataFrame([]),
            "railways": gpd.GeoDataFrame([]),
            "waterways": gpd.GeoDataFrame([]),
            # power grid data
            "ehv_data": davestructure(
                {"ehv_nodes": gpd.GeoDataFrame([]), "ehv_lines": gpd.GeoDataFrame([])}
            ),
            "hv_data": davestructure(
                {"hv_nodes": gpd.GeoDataFrame([]), "hv_lines": gpd.GeoDataFrame([])}
            ),
            "mv_data": davestructure(
                {"mv_nodes": gpd.GeoDataFrame([]), "mv_lines": gpd.GeoDataFrame([])}
            ),
            "lv_data": davestructure(
                {"lv_nodes": gpd.GeoDataFrame([]), "lv_lines": gpd.GeoDataFrame([])}
            ),
            "components_power": davestructure(
                {
                    "loads": gpd.GeoDataFrame([]),
                    "renewable_powerplants": gpd.GeoDataFrame([]),
                    "conventional_powerplants": gpd.GeoDataFrame([]),
                    "transformers": davestructure(
                        {
                            "ehv_ehv": gpd.GeoDataFrame([]),
                            "ehv_hv": gpd.GeoDataFrame([]),
                            "hv_mv": gpd.GeoDataFrame([]),
                            "mv_lv": gpd.GeoDataFrame([]),
                        }
                    ),
                    "substations": davestructure(
                        {
                            "ehv_hv": gpd.GeoDataFrame([]),
                            "hv_mv": gpd.GeoDataFrame([]),
                            "mv_lv": gpd.GeoDataFrame([]),
                        }
                    ),
                }
            ),
            # gas grid data
            "hp_data": davestructure(
                {"hp_junctions": gpd.GeoDataFrame([]), "hp_pipes": gpd.GeoDataFrame([])}
            ),
            "mp_data": davestructure(
                {"mp_junctions": gpd.GeoDataFrame([]), "mp_pipes": gpd.GeoDataFrame([])}
            ),
            "lp_data": davestructure(
                {"lp_junctions": gpd.GeoDataFrame([]), "lp_pipes": gpd.GeoDataFrame([])}
            ),
            "components_gas": davestructure(
                {
                    "compressors": gpd.GeoDataFrame([]),
                    "sinks": gpd.GeoDataFrame([]),
                    "sources": gpd.GeoDataFrame([]),
                    "storages_gas": gpd.GeoDataFrame([]),
                    "valves": gpd.GeoDataFrame([]),
                }
            ),
            # building height data
            "building_height": gpd.GeoDataFrame([]),
            # census data
            "census_data": davestructure(
                {
                    "population": gpd.GeoDataFrame([]),
                }
            ),
            # auxillary
            "dave_version": client_settings()["dave_version"],
            "meta_data": {},
        }
    )
    return grid_data
